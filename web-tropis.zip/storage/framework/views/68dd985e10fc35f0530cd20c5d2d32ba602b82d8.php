  <?php
      use App\Models\Tb_setting;
      use App\Models\Tb_menu;
      use App\Models\Tb_submenu;
      $setting = Tb_setting::find(1);
      $menu = Tb_menu::orderBy('urutan', 'asc')->get();
  ?>
  <!-- ======= Header ======= -->
 <!-- ======= Header ======= -->
 <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<header id="header" class="header fixed-top fixed-top-scroll">
    <div class="container-fluid container-xl">
       <div class="header-content d-flex align-items-center justify-content-between">
                <!-- Logo dan Nama Logo -->
                <a href="/" class="logo d-flex align-items-center">
                    <img src="<?php echo e(asset('assets/frontend/assets/img/logotropis.png')); ?>" alt="">
                    <span class="brand-name"><p>TROPIS KOPI</p></span>
                </a>
            </div>
            <div class="col-lg-6">
                <nav id="navbar" class="navbar">
                    <ul>
                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($item->id_konten === 0): ?>
                                <li class="dropdown"><a style="color: #45C818;"
                                        href="#"><span><?php echo e($item->nama); ?></span> <i class="bi bi-chevron-down"></i></a>
                                    <ul>
                                        <li>
                                            <?php
                                                $submenu = Tb_submenu::orderBy('urutan', 'asc')
                                                    ->where('id_menu', $item->id)
                                                    ->get();
                                            ?>
                                            <?php $__currentLoopData = $submenu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($data->konten->link || $data->konten->link != null): ?>
                                                    <a href="<?php echo e($data->konten->link->link); ?>"
                                                        class="dropdown-item <?php echo e(Request::is('') ? 'active text-warning' : ''); ?>"><?php echo e($data->nama); ?></a>
                                                <?php else: ?>
                                                    <a href="/s=><?php echo e($data->slug); ?>"><?php echo e($data->nama); ?></a>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </li>
                                    </ul>
                                </li> 
                            <?php else: ?>
                                <?php if($item->konten->link || $item->konten->link != null): ?>
                                    <li>
                                        <a href="<?php echo e($item->konten->link->link); ?>"
                                            class="dropdown-item <?php echo e(Request::is('') ? 'active text-warning' : ''); ?>"><?php echo e($item->nama); ?></a>
                                    </li> 
                                <?php else: ?>
                                    
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <i class="bi bi-list mobile-nav-toggle"></i>
                </nav><!-- .navbar -->
            </div>
        </div>
    </div>
</header><!-- End Header -->
<div class="search-logo">
    <img src="<?php echo e(asset('assets/frontend/assets/img/AA.png')); ?>" alt="Search Icon" width="180">
</div>

    
    
    
    
    
    <?php /**PATH C:\xampp\htdocs\web-tropis\resources\views/layouts/partials/member/header.blade.php ENDPATH**/ ?>