@extends('layouts.member')

@section('js')
    <!-- Make sure you put this AFTER Leaflet's CSS -->
    <script src="https://unpkg.com/leaflet@1.3.1/dist/leaflet.js"
        integrity="sha512-/Nsx9X4HebavoBvEBuyp3I7od5tA0UzAxs+j83KgC8PU0kgB4XiK4Lfe4y4cgBtaRJQEIFCW+oC506aPT2L1zw=="
        crossorigin=""></script>
    <script src="https://unpkg.com/leaflet.markercluster@1.4.1/dist/leaflet.markercluster.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/typed.js@2.0.12"></script>
    <script src="https://cdn.jsdelivr.net/npm/aos@2.3.4/dist/aos.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
    <link rel="stylesheet" id="picostrap-styles-css" href="https://cdn.livecanvas.com/media/css/library/bundle.css" media="all">
    <!-- CSS Files -->
    <link rel="stylesheet" href="https://cdn.ayroui.com/1.0/css/tiny-slider.css" />
    <link rel="stylesheet" href="https://unpkg.com/bootstrap@5.3.2/dist/css/bootstrap.min.css" />
    <link rel="stylesheet" href="https://unpkg.com/bs-brain@2.0.2/components/teams/team-2/assets/css/team-2.css" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@300&display=swap" rel="stylesheet">
    
<script>
    AOS.init();
  </script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script>
        axios.get('https://api.belajar.link/public/paket')
            .then(function(response) {
                var data = response;
                console.log('Data', data)
            })
            .catch(function(error) {
                console.log(error);
            });
    </script>
@endsection

@section('content')
    @php
        use Illuminate\Support\Facades\Http;
        use App\Models\Tb_tentang;
        use App\Models\Tb_keuntungan;
        use App\Models\Tb_pertanyan;
        use App\Models\Produk;
        use App\Models\Tb_artikel;
        use Illuminate\Support\Carbon;
        
        $tentang = Tb_tentang::find(1);
        $keuntungan = Tb_keuntungan::find(1);
        $pertanyaan = Tb_pertanyan::all();
        $produk = Produk::all();
                $artikel = Tb_artikel::paginate(3);

    @endphp   

<section id="hero" class="heroo d-flex align-items-center">
  <div class="container">
      <div class="row">
          <div class="col-lg-6 d-flex flex-column justify-content-center">
              <p data-aos="fade-right" style="margin-top: 0px"><font color="white"><b>Anda butuh teman <br> <br> santai di waktu <br> <br> malam menjelang?</b></font></p>
                 <img src="{{ asset('assets/frontend/assets/img/w.png') }}" alt="Deskripsi gambar Anda" style="width: 350px; height: auto; margin-left: -90px; margin-top: -65px" data-aos="fade-right"  data-aos-offset="100"  data-aos-easing="ease-in-sine">
      
              <br>
              <h2 style="margin-top: -90px; margin-left: 60px; font-weight: 50; font-size: 20px" id="" data-aos="fade-up"><font color ="white"></font></h2>
              <br>
              <br>
          </div>
      </div>
  </div>  
  <div class="text-center" style="position: absolute; bottom: 0; left: 80%; transform: translateX(-50%);">

  </div>  
</section><!-- End Hero -->


            

    
    

    <!-- About Trofis Coffe -->

    <section class="py-5 section-2">
      <div class="container">
        <div class="row gx-4 align-items-center justify-content-between">
          <h2 class="display-5 fw-bold" style="color: black; font-size: 80px; font-weight: 700; text-align: center; margin-bottom: 100px" data-aos="fade-up" data-aos-duration="500">TROPIS KOPI</h2>
          <div class="col-md-6 order-2 order-md-1">
            <div class="mt-5 mt-md-0" style="margin-left: 200px; text-align:justify; margin-bottom: 45px">
              <br>
              <br>
              <p id="write" class="lead" data-aos="fade-up" data-aos-duration="500">Tropis kopi adalah kopi 100% arabika murni dari pegunungan maynglayang dengan ketinggian 1400 - 1600 mdpl masyarakat indonesia</p>
            </div>
            <img src="{{ asset('assets/frontend/assets/img/bl.png') }}" alt="Deskripsi gambar Anda" style="width: 250px; height: 155; margin-left: 3%; margin-top: -33%" align="left" data-aos="fade-up" data-aos-duration="500">
          </div>
          <div class="col-md-5 order-1 order-md-2"><img class="img-fluid rounded-3" data-aos="fade-left" data-aos-duration="500" src="{{ asset('assets/frontend/assets/img/tropis.jpg') }}" alt="Deskripsi gambar Anda" width="300" height="00"></div>
        </div>
      </div>
    </section>

      <section class="py-5 must-coffe">
        <div class="container">
          <div class="row justify-content-center text-center mb-4 mb-md-5">
            <div class="col-xl-9 col-xxl-8">
              <span class="text-muted"></span>
              <br>
              <br>
              <br>
              <h2 class="display-5 fw-bold" style="font-size: 80px; font-weight: 700; color: white" data-aos="fade-up" data-aos-duration="500">KENAPA TROPIS KOPI?</h2>
              <p class="lead"></p>
              <br>
              <br>
            </div>
          </div>
          <div class="row g-0 align-items-center" style="margin-left: 200px">
            <div class="col-md-6 order-2 order-md-1">
              <div class="row justify-content-end">
                <div class="col-lg-12 col-xxl-10 col-xl-12">
                  <div class="p-md-3 p-xl-5 mt-4 mt-md-0 d-flex" >
                    <a class="text-primary fw-semibold text-decoration-none" href=""></a>
                    <span style="font-size: 80px; font-weight: 700; margin-top: -50px; color: #40281e" data-aos="fade-up" data-aos-duration="500">01</span>
                    <h2 style="margin-top: -20px; font-size: 30px; margin-left: 20px; color: white; font-weight:200;" data-aos="fade-up" data-aos-duration="500">
                      <b>Kopi</b><br>Arabika
                      </h2>
                  </div>
                  <img src="{{ asset('assets/frontend/assets/img/w.png') }}" alt="Deskripsi gambar Anda"  width="220" height="160" style="margin-top: -100px" data-aos="fade-up" data-aos-duration="500">
                  <div class="p-md-3 p-xl-5 mt-0 mt-md-0">
                      <p style="margin-top: -100px; margin-left: 70px; color: white; font-weight: lighter;" data-aos="fade-up" data-aos-duration="500">Menggunakan 100% kopi arabika asli</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 order-1 order-md-2">
              <div class="mt-5 mt-md-0"><img alt="" class="img-fluid" src="{{ asset('assets/frontend/assets/img/arbika.jpeg') }}"  data-aos="fade-right" data-aos-duration="500" width="200" height="200"></div>
            </div>
          </div>
        </div>
        <br>
        <br>
          <div class="row g-0 align-items-center" style="margin-left: 150px">
            <div class="col-md-4" style="margin-left: 70px"><img alt="" class="img-fluid" src="{{ asset('assets/frontend/assets/img/arbika.jpeg') }}" data-aos="fade-left"  data-aos-duration="500" alt="Deskripsi gambar Anda" width="200" height="200" style="margin-left: 110px"></div>
            <div class="col-md-6">
              <div class="row">
                <div class="col-lg-12 col-xxl-10 col-xl-12">
                  <div class="p-md-3 p-xl-5 mt-4 mt-md-0 d-flex" >
                    <a class="text-primary fw-semibold text-decoration-none" href=""></a>
                    <span style="font-size: 80px; font-weight: 700; margin-top: -50px; color: #40281e" data-aos="fade-up" data-aos-duration="500">02</span>
                    <h2 style="margin-top: -20px; font-size: 30px; margin-left: 20px; color: white; font-weight:200;" data-aos="fade-up" data-aos-duration="500">
                      <b>Cita Rasa</b><br>Khas
                      </h2>
                  </div>
                  <img src="{{ asset('assets/frontend/assets/img/w.png') }}" alt="Deskripsi gambar Anda" width="220" height="160" style="margin-top: -100px" data-aos="fade-up" data-aos-duration="500">
                  <div class="p-md-3 p-xl-5 mt-0 mt-md-0">
                    <p style="margin-top: -100px; margin-left: 70px; color: white; font-weight: lighter; margin-right: 90px" data-aos="fade-up" data-aos-duration="500">Cita rasa pegunungan manglayang, wangi soft dan nikmat</p>
                </div>
                </div>
              </div>
            </div>
          </div>
          <br>
          <br>
          <div class="row g-0 align-items-center" style="margin-left: 270px">
            <div class="col-md-6 order-2 order-md-1">
              <div class="row justify-content-end">
                <div class="col-lg-12 col-xxl-10 col-xl-12">
                  <div class="p-md-3 p-xl-5 mt-4 mt-md-0 d-flex" >
                    <a class="text-primary fw-semibold text-decoration-none" href=""></a>
                    <span style="font-size: 80px; font-weight: 700; margin-top: -50px; color: #40281e"  data-aos="fade-up" data-aos-duration="500">03</span>
                    <h2 style="margin-top: -20px; font-size: 30px; margin-left: 20px; color: white; font-weight:200;"  data-aos="fade-up" data-aos-duration="500">
                      <b>Baik Untuk</b><br>Untuk Kesehatan
                      </h2>
                  </div>
                  <img src="{{ asset('assets/frontend/assets/img/w.png') }}" alt="Deskripsi gambar Anda" width="220" height="160" style="margin-top: -100px">
                  <div class="p-md-3 p-xl-5 mt-0 mt-md-0">
                      <p style="margin-top: -100px; margin-left: 70px; color: white; font-weight: lighter;"  data-aos="fade-up" data-aos-duration="500">Antioksidan, mengurangi resiko diabetes, azheimer, parkinson, dan lainnya</p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-6 order-1 order-md-2">
              <div class="mt-5 mt-md-0"><img alt="" class="img-fluid" src="{{ asset('assets/frontend/assets/img/arbika.jpeg') }}" data-aos="fade-right" data-aos-duration="500" width="200" height="200"></div>
            </div>
          </div>
        </div>
        <br>
        <br>
      </section>
    <section id="about" class="section-2">
        <div class="container" data-aos="fade-up">
          <header class="section-header-p-2">
            <p><span class=""><font color="black">MANFAAT</font></span></p>
          </header>
          <br>
          <div class="row">
            <div class="col-lg-6-h-2 col-description-2">
                <img src="{{ asset('assets/frontend/assets/img/bl.png') }}" alt="Deskripsi gambar Anda" style="width: 255px; height: 150; margin-left: 100px; margin-top: -10px">
            <p style="margin-left: 100px; margin-top: -10px;"><b>1.</b> Mengurangi kadar kolestrol <br> 2. Mencegah terjadinya kanker <br> 3. Mencegah timbulnya parkinson <br> 4. Menghambat resiko penuaan dini <br> 5. Aman di lambung</p>
          </div>
              <div class="col-lg-6 style-img" data-aos="zoom-out" data-aos-delay="200">
              </div>
          </div>
        </div>
      </section>
      <br>
      <br>
      <br>
      <section class="py-5 section-3">
        <div class="container">
          <!--- Heading -->
          <div class="row text-center mb-4">
            <div class="col-12 col-lg-10 col-xl-8 mx-auto text-center">
              <p class="text-muted mb-0 fw-light"></p>
              <h2 style="font-size: 80px; font-weight: 700; color: black" data-aos="fade-up" data-aos-duration="500">PROSES TERPILIHNYA <br> KOPI TERBAIK</h2>
              <p class="lead mb-4"></p>
              <br>
              <br>
            </div>
          </div><!--- Steps Wrap -->
          <div class="row justify-content-center">
            <div class="col-lg-9">
              <div class="row">
                <!-- Step -->
                <div class="col-lg-4">
                  <div class="text-center position-relative">
                    <!-- Step Icon -->
                    <div class="step-icon mx-auto border border-2 border rounded-circle d-flex align-items-center justify-content-center" style="width:150px;height:150px" data-aos="fade-right" data-aos-duration="500">
                      <img src="{{ asset('assets/frontend/assets/img/ptk.png') }}" alt="Deskripsi gambar Anda" width="430" height="250" style="margin-left: 20px">
                    </div>
                    <h4 class="mt-3 fs-5">1. Petik ceri merah</h4>
                    <p class="text-muted mt-4 fs-6 px-lg-3 mb-5 mb-lg-0"></p><!-- Arrow Icon -->
                    <div class="arrow-icon position-absolute d-none d-lg-block" style="top:50px; right:-25px">
                      <svg class="bi bi-arrow-right" height="30" viewbox="0 0 16 16" width="30" xmlns="http://www.w3.org/2000/svg" data-aos="fade-right" data-aos-duration="500">
                      <path d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z" fill-rule="evenodd"></path></svg>
                    </div>
                  </div>
                </div><!-- Step -->
                <div class="col-lg-4">
                  <div class="text-center position-relative">
                    <!-- Step Icon -->
                    <div class="step-icon mx-auto border border-2 border rounded-circle d-flex align-items-center justify-content-center" style="width: 150px;height: 150px;" data-aos="fade-right" data-aos-duration="1000">
                      <img src="{{ asset('assets/frontend/assets/img/aki.png') }}" alt="Deskripsi gambar Anda" width="430" height="250" style="margin-left: 20px">
                    </div>
                    <h4 class="mt-3 fs-5">2. Sortasi awal</h4>
                    <p class="text-muted mt-4 fs-6 px-lg-3 mb-5 mb-lg-0"></p><!-- Arrow Icon -->
                    <div class="arrow-icon d-none d-lg-block position-absolute" style="top:50px; right:-25px">
                      <svg class="bi bi-arrow-right" height="30" viewbox="0 0 16 16" width="30" xmlns="http://www.w3.org/2000/svg" data-aos="fade-right" data-aos-duration="500">
                      <path d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z" fill-rule="evenodd"></path></svg>
                    </div>
                  </div>
                </div><!-- Step -->
                <div class="col-lg-4">
                  <div class="text-center position-relative">
                    <!--- Step Icon -->
                    <div class="step-icon mx-auto border border-2 border rounded-circle d-flex align-items-center justify-content-center" style="width: 150px;height: 150px;" data-aos="fade-right" data-aos-duration="1500">
                      <img src="{{ asset('assets/frontend/assets/img/pram.png') }}" alt="Deskripsi gambar Anda" width="430" height="250" style="margin-left: 20px">
                    </div>
                    <h4 class="mt-3 fs-5">3. Peambangan</h4>
                    <p class="text-muted mt-4 fs-6 px-lg-3 mb-5 mb-lg-0"></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <br>
          <div class="row justify-content-center">
            <div class="col-lg-9">
              <div class="row">
                <!-- Step -->
                <div class="col-lg-4">
                  <div class="text-center position-relative">
                    <!-- Step Icon -->
                    <div class="step-icon mx-auto border border-2 border rounded-circle d-flex align-items-center justify-content-center" style="width:150px;height:150px" data-aos="fade-right" data-aos-duration="500">
                      <img src="{{ asset('assets/frontend/assets/img/wahs.png') }}" alt="Deskripsi gambar Anda" width="430" height="250" style="margin-left: 20px">
                    </div>
                    <h4 class="mt-3 fs-5">4. Pencucian</h4>
                    <p class="text-muted mt-4 fs-6 px-lg-3 mb-5 mb-lg-0"></p><!-- Arrow Icon -->
                    <div class="arrow-icon position-absolute d-none d-lg-block" style="top:50px; right:-25px">
                      <svg class="bi bi-arrow-right" height="30" viewbox="0 0 16 16" width="30" xmlns="http://www.w3.org/2000/svg" data-aos="fade-right" data-aos-duration="500">
                      <path d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z" fill-rule="evenodd"></path></svg>
                    </div>
                  </div>
                </div><!-- Step -->
                <div class="col-lg-4">
                  <div class="text-center position-relative">
                    <!-- Step Icon -->
                    <div class="step-icon mx-auto border border-2 border rounded-circle d-flex align-items-center justify-content-center" style="width: 150px;height: 150px;" data-aos="fade-right" data-aos-duration="1000">
                      <img src="{{ asset('assets/frontend/assets/img/pengg.png') }}" alt="Deskripsi gambar Anda" width="430" height="250" style="margin-left: 20px">
                    </div>
                    <h4 class="mt-3 fs-5">5. Pengeringan</h4>
                    <p class="text-muted mt-4 fs-6 px-lg-3 mb-5 mb-lg-0"></p><!-- Arrow Icon -->
                    <div class="arrow-icon d-none d-lg-block position-absolute" style="top:50px; right:-25px">
                      <svg class="bi bi-arrow-right" height="30" viewbox="0 0 16 16" width="30" xmlns="http://www.w3.org/2000/svg">
                      <path d="M1 8a.5.5 0 0 1 .5-.5h11.793l-3.147-3.146a.5.5 0 0 1 .708-.708l4 4a.5.5 0 0 1 0 .708l-4 4a.5.5 0 0 1-.708-.708L13.293 8.5H1.5A.5.5 0 0 1 1 8z" fill-rule="evenodd"></path></svg>
                    </div>
                  </div>
                </div><!-- Step -->
                <div class="col-lg-4">
                  <div class="text-center position-relative">
                    <!--- Step Icon -->
                    <div class="step-icon mx-auto border border-2 border rounded-circle d-flex align-items-center justify-content-center" style="width: 150px;height: 150px;" data-aos="fade-right" data-aos-duration="1500">
                      <img src="{{ asset('assets/frontend/assets/img/crash.png') }}" alt="Deskripsi gambar Anda" width="430" height="250" style="margin-left: 20px">
                    </div>
                    <h4 class="mt-3 fs-5">6. Hulling</h4>
                    <p class="text-muted mt-4 fs-6 px-lg-3 mb-5 mb-lg-0"></p>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <img src="{{ asset('assets/frontend/assets/img/bl.png') }}" alt="Deskripsi gambar Anda" style="width: 350px; height: auto; margin-left: 380px; margin-top: -10px">
        </div>
      </section>
    <section class="py-5 section-5">
      <div class="container" style="margin-top: 0px">
        <!--- Heading -->
        <div class="row text-center mb-4">
          <div class="col-12 col-lg-10 col-xl-8 mx-auto text-center">
            <p class="text-muted mb-0 fw-light"></p>
            <h2 style="color: white; font-size: 80px; letter-spacing: 0; font-weight: 700;" data-aos="fade-up" data-aos-duration="500">PELAYANAN YANG AKAN DI DAPATKAN</h2>
            <p class="lead mb-0">.</p>
          </div>
        </div><!--- Steps Wrap -->
        <div class="row justify-content-center pt-5">
          <div class="col-lg-9">
            <div class="row">
              <div class="col-lg-4">
                <div class="card rounded-5 text-center p-3 bg-warning-emphasis px-5 mb-5 mb-lg-0"  data-aos="zoom-in">
                  <div class="d-flex rounded-circle mx-auto align-items-center justify-content-center text-white fs-3 fw-bold bg-secondary border border-white border-4"  data-aos="zoom-in" style="width: 4rem; height:4rem; margin-top:-3.5rem;">
                    <img src="{{ asset('assets/frontend/assets/img/crt.png') }}" alt="Deskripsi gambar Anda" width="35" height="30">
                  </div>
                  <br>
                  <h5 class="mt-3 mb-4"><b>1000+</b> <br> Pesanan</h5>
                  <p class="text-muted"></p>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="card rounded-5 text-center p-3 bg-light px-5 mb-5 mb-lg-0"  data-aos="zoom-in">
                  <div class="d-flex rounded-circle mx-auto align-items-center justify-content-center text-white fs-3 fw-bold bg-secondary border border-white border-4"  data-aos="zoom-in" style="width: 4rem; height:4rem; margin-top: -3.5rem;">
                    <img src="{{ asset('assets/frontend/assets/img/cus.png') }}" alt="Deskripsi gambar Anda" width="35" height="30">
                  </div>
                  <br>
                  <h5 class="mt-3 mb-4"><b>Fast Respon</b> <br> Customer Services</h5>
                  <p class="text-muted"></p>
                </div>
              </div>
              <div class="col-lg-4">
                <div class="card rounded-5 text-center p-3 bg-light px-5 mb-5 mb-lg-0"  data-aos="zoom-in">
                  <div class="d-flex rounded-circle mx-auto align-items-center justify-content-center text-white fs-3 fw-bold bg-secondary border border-white border-4"  data-aos="zoom-in"  style="width: 4rem; height:4rem; margin-top: -3.5rem;">
                    <img src="{{ asset('assets/frontend/assets/img/o.png') }}" alt="Deskripsi gambar Anda" width="35" height="30">
                  </div>
                  <br>
                  <h5 class="mt-3 mb-4"><b>Pengiriman</b> <br> SeIndonesia</h5>
                  <p class="text-muted"></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

      <section class="py-5 section-6">
        <div class="container">
          <div class="row justify-content-center text-center mb-2 mb-lg-4">
            <div class="col-12 col-lg-8 col-xxl-7 text-center mx-auto">
              <h2 class="display-5 fw-bold" style="color: white; font-size: 80px" data-aos="fade-up" data-aos-duration="500">TESTIMONI</h2>
              <img src="{{ asset('assets/frontend/assets/img/w.png') }}" alt="Deskripsi gambar Anda" style="width: 350px; height: auto; margin-left: 5px; margin-top: -10px">
              <br>
            </div>
          </div>
          <div class="row g-5 py-4 justify-content-center">
            <div class="col-lg-8">
              <div class="d-flex align-items-start mb-4">
                <img alt="" class="img-fluid me-3" height="0" width="500" src="{{ asset('assets/frontend/assets/img/tst.png') }}" width="96" data-aos="fade-up" data-aos-duration="500">
                <div class="bg-light p-3 p-md-4" data-aos="fade-left" data-aos-duration="500">
                  <div class="text-primary mb-1">
                    <svg class="bi bi-quote" fill="gray" height="32" viewbox="0 0 16 16" width="32" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 12a1 1 0 0 0 1-1V8.558a1 1 0 0 0-1-1h-1.388c0-.351.021-.703.062-1.054.062-.372.166-.703.31-.992.145-.29.331-.517.559-.683.227-.186.516-.279.868-.279V3c-.579 0-1.085.124-1.52.372a3.322 3.322 0 0 0-1.085.992 4.92 4.92 0 0 0-.62 1.458A7.712 7.712 0 0 0 9 7.558V11a1 1 0 0 0 1 1h2Zm-6 0a1 1 0 0 0 1-1V8.558a1 1 0 0 0-1-1H4.612c0-.351.021-.703.062-1.054.062-.372.166-.703.31-.992.145-.29.331-.517.559-.683.227-.186.516-.279.868-.279V3c-.579 0-1.085.124-1.52.372a3.322 3.322 0 0 0-1.085.992 4.92 4.92 0 0 0-.62 1.458A7.712 7.712 0 0 0 3 7.558V11a1 1 0 0 0 1 1h2Z"></path></svg>
                  </div>
                  <p class="lead">Saya sangat menyukai kopi ini karena rasanya yang kuat dan aroma yang khas. saya sudah mencoba banyak jenis kopi tetapi kopi ini adalah yang terbaik</p>
                  <div class="text-end pt-2">
                    <h5 class="fw-bold">Atalia</h5>
                    <div class="text-muted">
                      Ibu Gubernur Jawa Barat
                    </div>
                  </div>
                </div>
              </div>
              <div class="d-flex align-items-start mb-4">
                <img alt="" class="img-fluid me-3" height="0" width="500" src="{{ asset('assets/frontend/assets/img/tst2.png') }}" width="96" data-aos="fade-up" data-aos-duration="500">
                <div class="bg-light p-3 p-md-4" data-aos="fade-left" data-aos-duration="500">
                  <div class="text-primary mb-1">
                    <svg class="bi bi-quote" fill="gray" height="32" viewbox="0 0 16 16" width="32" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 12a1 1 0 0 0 1-1V8.558a1 1 0 0 0-1-1h-1.388c0-.351.021-.703.062-1.054.062-.372.166-.703.31-.992.145-.29.331-.517.559-.683.227-.186.516-.279.868-.279V3c-.579 0-1.085.124-1.52.372a3.322 3.322 0 0 0-1.085.992 4.92 4.92 0 0 0-.62 1.458A7.712 7.712 0 0 0 9 7.558V11a1 1 0 0 0 1 1h2Zm-6 0a1 1 0 0 0 1-1V8.558a1 1 0 0 0-1-1H4.612c0-.351.021-.703.062-1.054.062-.372.166-.703.31-.992.145-.29.331-.517.559-.683.227-.186.516-.279.868-.279V3c-.579 0-1.085.124-1.52.372a3.322 3.322 0 0 0-1.085.992 4.92 4.92 0 0 0-.62 1.458A7.712 7.712 0 0 0 3 7.558V11a1 1 0 0 0 1 1h2Z"></path></svg>
                  </div>
                  <p class="lead">Kopi ini sangat cocok untuk dinikmati di pagi hari karena rasanya yang segar dan aroma yang menyenangkan. Saya sangat merekomendasikan kopi ini untuk semua orang.</p>
                  <div class="text-end pt-2">
                    <h5 class="fw-bold">HJ Doni Ahmad</h5>
                    <div class="text-muted">
                      Bupati Sumedang
                    </div>
                  </div>
                </div>
              </div>
              <div class="d-flex align-items-start mb-4">
                <img alt="" class="img-fluid me-3" height="0" width="500" src="{{ asset('assets/frontend/assets/img/tst3.png') }}" width="96" data-aos="fade-up" data-aos-duration="500">
                <div class="bg-light p-3 p-md-4" data-aos="fade-left" data-aos-duration="500">
                  <div class="text-primary mb-1">
                    <svg class="bi bi-quote" fill="gray" height="32" viewbox="0 0 16 16" width="32" xmlns="http://www.w3.org/2000/svg">
                    <path d="M12 12a1 1 0 0 0 1-1V8.558a1 1 0 0 0-1-1h-1.388c0-.351.021-.703.062-1.054.062-.372.166-.703.31-.992.145-.29.331-.517.559-.683.227-.186.516-.279.868-.279V3c-.579 0-1.085.124-1.52.372a3.322 3.322 0 0 0-1.085.992 4.92 4.92 0 0 0-.62 1.458A7.712 7.712 0 0 0 9 7.558V11a1 1 0 0 0 1 1h2Zm-6 0a1 1 0 0 0 1-1V8.558a1 1 0 0 0-1-1H4.612c0-.351.021-.703.062-1.054.062-.372.166-.703.31-.992.145-.29.331-.517.559-.683.227-.186.516-.279.868-.279V3c-.579 0-1.085.124-1.52.372a3.322 3.322 0 0 0-1.085.992 4.92 4.92 0 0 0-.62 1.458A7.712 7.712 0 0 0 3 7.558V11a1 1 0 0 0 1 1h2Z"></path></svg>
                  </div>
                  <p class="lead">Kopi ini memiliki rasa yang kuat dan pahit, tetapi aroma yang dihasilkan sangatlah menenangkan. Saya sangat merekomendasikan kopi ini untuk para pencinta kopi</p>
                  <div class="text-end pt-2">
                    <h5 class="fw-bold">Pecinta Kopi</h5>
                    <div class="text-muted">
                      Coffe Lovers
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="py-5 section-7">
        <div class="container">
          <div class="row gx-4 align-items-center justify-content-between">
            <div class="col-md-6 order-2 order-md-1">
              <div class="mt-5 mt-0 me-md-3 me-lg-5">
                <span class="text-muted"></span>
                <h2 class="fw-bold" style="font-size: 80px; margin-left: 440px; margin-top: -150px; color: black" data-aos="fade-up" data-aos-duration="500">PRODUK</h2>
                <p class="lead"></p>
                <br>
                <br>
              </div>
              <br>
              <br>
            </div>
            <div class="col-md-8 order-1 order-md-2">
              <div class="row gx-2 gx-lg-3">
                <div class="col-6">
                  <img class="img-fluid rounded-3" src="{{ asset('assets/frontend/assets/img/produk.png') }}" width="300" height="225" data-aos="fade-right" data-aos-duration="500">
                  <p style="font-size: 30px; font-weight:bolder; text-align:center; margin-right: 50px; margin-top: 20px" data-aos="fade-up" data-aos-duration="500">GROUNDBEAN</p>
                  <p style="font-size: 20px; font-weight:lighter; text-align:center; margin-right: 50px;" data-aos="fade-up" data-aos-duration="500">Arabika 1-250 GR</p>
                </div>
                <div class="col-6">
                  <img class="img-fluid rounded-3" src="{{ asset('assets/frontend/assets/img/produk.png') }}" width="300" height="225" data-aos="fade-right" data-aos-duration="500">
                  <p style="font-size: 30px; font-weight:bolder; text-align:center; margin-right: 50px; margin-top: 20px" data-aos="fade-up" data-aos-duration="500">GREENBEAN</p>
                  <p style="font-size: 20px; font-weight:lighter; text-align:center; margin-right: 50px;" data-aos="fade-up" data-aos-duration="500">Arabika 1-50 KG</p>
                </div>
                <img src="{{ asset('assets/frontend/assets/img/bl.png') }}" alt="Deskripsi gambar Anda" style="width: 200px; height: 125px; margin-left: 700px; margin-top: -460px" data-aos="fade-left" data-aos-duration="500">
              </div>
            </div>
          </div>
        </div>
      </section>

      <section class="py-5 section-8">
        <div class="container">
          <div class="row justify-content-center">
            <div class="col-md-6">
              <div class="text-center" style="margin-top: 190px">
                <img src="{{ asset('assets/frontend/assets/img/logotropis.png') }}" alt="" width="15" height="15" data-aos="fade-right" data-aos-duration="500">
                <span class="" style="text-align: left; color: white; margin-right: 450px" data-aos="fade-left" data-aos-duration="500">TROPIS KOPI</span>
                <br>
                <br>
                <h2 class="display-5 fw-bold" style="text-align: left; font-size: 80px" data-aos="fade-right" data-aos-duration="500">READY STOK. <br> SPESIAL PROMO.</h2>
                <p class="lead" data-aos="zoom-in" data-aos-duration="500">Berapa Harganya? <strike> Rp. 75.000 </strike> &nbsp; Menjadi  &nbsp;  <b> Rp. 50.000 </b>  </p>
              </div>
            </div>
          </div>
          <img src="{{ asset('assets/frontend/assets/img/bl.png') }}" alt="Deskripsi gambar Anda" style="margin-top: -100px; margin-right: -65px" align="right" data-aos="fade-left" data-aos-duration="500" width="250" height="155">
          <br>
          <br>
          <br>
          <p style="margin-left: 790px" class="lead" style="text-align: justify" data-aos="zoom-in" data-aos-duration="500">PRODUK 100% ORIGINAL,  HATI HATI BARANG PALSU. JANGAN MUDAH PERCAYA DENGAN PRODUK YANG LEBIH MURAH DARI KAMI  </p>
        </div>
      </section>

      <section class="py-5 section-9">
        <div class="container">
          <div class="row justify-content-center text-center py-4">
            <div class="col-lg-8">
              <span style="color: white">Penawaran Terbatas !</span>
              <h2 class="display-5 fw-bold my-2" style="color: white">HARGA SPESIAL HANYA UNTUK ANDA</h2>
              <div class="mx-auto py-2">
                <a class="btn btn-success btn-lg me-2" href="https://wa.link/2dsj4u">Klik Disini </a> 
              </div>
            </div>
          </div>
        </div>
      </section>

    

 <script src="https://cdn.ayroui.com/1.0/js/tiny-slider.js"></script>
 <script>
var TxtType = function(el, toRotate, period) {
        this.toRotate = toRotate;
        this.el = el;
        this.loopNum = 0;
        this.period = parseInt(period, 10) || 2000;
        this.txt = '';
        this.tick();
        this.isDeleting = false;
    };

    TxtType.prototype.tick = function() {
        var i = this.loopNum % this.toRotate.length;
        var fullTxt = this.toRotate[i];
        
        if (this.isDeleting) {
        this.txt = fullTxt.substring(0, this.txt.length - 1);
        } else {
        this.txt = fullTxt.substring(0, this.txt.length + 1);
        }

        this.el.innerHTML = '<span class="wrap">'+this.txt+'</span>';

        var that = this;
        var delta = 200 - Math.random() * 100;

        if (this.isDeleting) { delta /= 2; }

        if (!this.isDeleting && this.txt === fullTxt) {
        delta = this.period;
        this.isDeleting = true;
        } else if (this.isDeleting && this.txt === '') {
        this.isDeleting = false;
        this.loopNum++;
        delta = 900;
        }

        setTimeout(function() {
        that.tick();
        }, delta);
    };

    window.onload = function() {
        var elements = document.getElementsByClassName('typewrite');
        for (var i=0; i<elements.length; i++) {
            var toRotate = elements[i].getAttribute('data-type');
            var period = elements[i].getAttribute('data-period');
            if (toRotate) {
              new TxtType(elements[i], JSON.parse(toRotate), period);
            }
        }
        // INJECT CSS
        var css = document.getElemen("style");
        css.type = "text/css";
        css.innerHTML = ".typewrite > .wrap { border-right: 0.08em solid #fff}";
        document.body.appendChild(css);
    };


 </script>
</body>

    </main>

    <!-- End main -->
@endsection

  
  
  
  
  