<?php
    use App\Models\Tb_kategori_artikel;
    $kategoriArtikel = Tb_kategori_artikel::paginate(9);
?>
<div>
    <div class="container py-5 mb-2">
        <section id="recent-blog-posts" class="recent-blog-posts">

            <div class="container" data-aos="fade-up">
                <div class="row">
                    <?php $__currentLoopData = $kategoriArtikel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4">
                            <div class="post-box">
                                <div class="post-img"><img src="<?php echo e($item->cover()); ?>" style="width: 100%" alt="">
                                </div>
                                <h3 class="post-title"><?php echo e($item->nama); ?></h3>
                                <a href="artikel/<?php echo e($item->slug); ?>"
                                    class="readmore stretched-link mt-auto float-right"
                                    style="float: right"><span>Lihat</span><i class="bi bi-arrow-right"></i></a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <center>
                <?php echo $kategoriArtikel->links(); ?>

            </center>
        </section>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\web-tropis\resources\views/components/artikel.blade.php ENDPATH**/ ?>