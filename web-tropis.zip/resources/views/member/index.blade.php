@extends('layouts.member')

@section('content')
    <div class="container-fluid">
        <div class="row px-xl-5">
            <div class="col-12">
                <nav class="breadcrumb bg-light mb-30" style="border-right: 5px solid rgb(255, 196, 0);">
                    <h5>SELAMAT DATANG</h5>
                </nav>
            </div>
        </div>
    </div>
@endsection
